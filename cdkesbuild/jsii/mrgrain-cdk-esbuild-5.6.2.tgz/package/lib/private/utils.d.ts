import { IConstruct } from 'constructs';
import { BuildOptions, Platform, TransformOptions } from '../esbuild-types';
export declare function isEsbuildError(error: unknown): boolean;
export declare function nodeMajorVersion(): number;
export declare function defaultPlatformProps(options?: BuildOptions | TransformOptions): {
    platform?: Platform;
    target?: string | string[];
};
export declare const uniqueAssetId: (scope: IConstruct, name: string) => string;
