import { CfnResource } from 'aws-cdk-lib';
import { ResourceBindOptions, Code, CodeConfig } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { BundlerProps, EntryPoints } from './bundler';
export { CodeConfig } from 'aws-cdk-lib/aws-lambda';
export interface TypeScriptCodeProps extends BundlerProps {
    /**
     * A hash of this asset, which is available at construction time.
     *
     * As this is a plain string, it can be used in construct IDs in order to enforce creation of a new resource when the content hash has changed.
     *
     * Defaults to a hash of all files in the resulting bundle.
     *
     * @stability stable
     */
    readonly assetHash?: string;
}
/**
 * Represents the deployed TypeScript Code.
 *
 * @stability stable
 */
export declare class TypeScriptCode extends Code {
    private props;
    private asset?;
    /**
     * Determines whether this Code is inline code or not.
     *
     * @deprecated this value is ignored since inline is now determined based on the the inlineCode field of CodeConfig returned from bind().
     */
    isInline: boolean;
    constructor(
    /**
     * A path or list or map of paths to the entry points of your code.
     *
     * Relative paths are by default resolved from the current working directory.
     * To change the working directory, see `buildOptions.absWorkingDir`.
     *
     * Absolute paths can be used if files are part of the working directory.
     *
     * Examples:
     *  - `'src/index.ts'`
     *  - `require.resolve('./lambda')`
     *  - `['src/index.ts', 'src/util.ts']`
     *  - `{one: 'src/two.ts', two: 'src/one.ts'}`
     *
     * @stability stable
     */
    entryPoints: EntryPoints, 
    /**
     * Props to change the behavior of the bundler.
     *
     * Default values for `props.buildOptions`:
     * - `bundle=true`
     * - `platform=node`
     * - `target=nodeX` with X being the major node version running locally
     *
     * @stability stable
     */
    props?: TypeScriptCodeProps);
    bind(scope: Construct): CodeConfig;
    /**
     * Called after the CFN function resource has been created to allow the code class to bind to it.
     *
     * Specifically it's required to allow assets to add
     * metadata for tooling like SAM CLI to be able to find their origins.
     *
     * @stability stable
     */
    bindToResource(resource: CfnResource, options?: ResourceBindOptions): void;
}
