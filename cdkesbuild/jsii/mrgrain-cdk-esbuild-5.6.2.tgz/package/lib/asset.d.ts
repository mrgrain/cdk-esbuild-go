import { Asset as S3Asset } from 'aws-cdk-lib/aws-s3-assets';
import { Construct } from 'constructs';
import { EntryPoints } from './bundler';
import { TypeScriptCodeProps } from './code';
export interface TypeScriptAssetProps extends TypeScriptCodeProps {
    /**
     * A path or list or map of paths to the entry points of your code.
     *
     * Relative paths are by default resolved from the current working directory.
     * To change the working directory, see `buildOptions.absWorkingDir`.
     *
     * Absolute paths can be used if files are part of the working directory.
     *
     * Examples:
     *  - `'src/index.ts'`
     *  - `require.resolve('./lambda')`
     *  - `['src/index.ts', 'src/util.ts']`
     *  - `{one: 'src/two.ts', two: 'src/one.ts'}`
     *
     * @stability stable
     */
    readonly entryPoints: EntryPoints;
}
/**
 * Bundles the entry points and creates a CDK asset which is uploaded to the bootstrapped CDK S3 bucket during deployment.
 *
 * The asset can be used by other constructs.
 *
 * @stability stable
 */
export declare class TypeScriptAsset extends S3Asset {
    /**
     * @stability stable
     */
    constructor(scope: Construct, id: string, props: TypeScriptAssetProps);
}
