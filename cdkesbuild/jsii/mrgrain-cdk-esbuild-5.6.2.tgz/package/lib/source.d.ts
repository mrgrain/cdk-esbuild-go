import { DeploymentSourceContext, ISource, SourceConfig } from 'aws-cdk-lib/aws-s3-deployment';
import { Construct } from 'constructs';
import { EntryPoints } from './bundler';
import { TypeScriptCodeProps } from './code';
export interface TypeScriptSourceProps extends TypeScriptCodeProps {
}
export declare class TypeScriptSource implements ISource {
    private props;
    private asset?;
    constructor(
    /**
     * A path or list or map of paths to the entry points of your code.
     *
     * Relative paths are by default resolved from the current working directory.
     * To change the working directory, see `buildOptions.absWorkingDir`.
     *
     * Absolute paths can be used if files are part of the working directory.
     *
     * Examples:
     *  - `'src/index.ts'`
     *  - `require.resolve('./lambda')`
     *  - `['src/index.ts', 'src/util.ts']`
     *  - `{one: 'src/two.ts', two: 'src/one.ts'}`
     *
     * @stability stable
     */
    entryPoints: EntryPoints, 
    /**
     * Props to change the behavior of the bundler.
     *
     * Default values for `props.buildOptions`:
     * - `bundle=true`
     * - `platform=browser`
     *
     * @stability stable
     */
    props?: TypeScriptSourceProps);
    bind(scope: Construct, context?: DeploymentSourceContext): SourceConfig;
}
