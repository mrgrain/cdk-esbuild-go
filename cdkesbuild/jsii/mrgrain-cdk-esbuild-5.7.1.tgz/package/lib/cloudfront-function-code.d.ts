import { FunctionCode } from 'aws-cdk-lib/aws-cloudfront';
import { BuildOptions } from './esbuild-types';
import { TransformerProps } from './inline-code';
import { IBuildProvider } from './provider';
/**
 * CloudFront Functions JavaScript runtime environment version.
 *
 * @stability stable
 */
export declare class CloudFrontFunctionRuntime {
    readonly value: string;
    /**
     * cloudfront-js-1.0 - limited ES6 support, no const/let, no async/await
     */
    static readonly JS_1_0: CloudFrontFunctionRuntime;
    /**
     * cloudfront-js-2.0 - enhanced ES6 support, const/let and async/await supported
     */
    static readonly JS_2_0: CloudFrontFunctionRuntime;
    private constructor();
}
/**
 * Properties for CloudFront Function TypeScript code.
 *
 * @stability stable
 */
export interface CloudFrontFunctionCodeProps {
    /**
     * CloudFront Functions JavaScript runtime environment version to build for.
     *
     * @default CloudFrontFunctionRuntime.JS_1_0
     */
    readonly runtime?: CloudFrontFunctionRuntime;
    /**
     * Build options passed on to esbuild. Please refer to the esbuild Build API docs for details.
     *
     * * `buildOptions.outdir: string`
     * The actual path for the output directory is defined by CDK. However setting this option allows to write files into a subdirectory. \
     * For example `{ outdir: 'js' }` will create an asset with a single directory called `js`, which contains all built files. This approach can be useful for static website deployments, where JavaScript code should be placed into a subdirectory. \
     * *Cannot be used together with `outfile`*.
     * * `buildOptions.outfile: string`
     * Relative path to a file inside the CDK asset output directory.
     * For example `{ outfile: 'js/index.js' }` will create an asset with a single directory called `js`, which contains a single file `index.js`. This can be useful to rename the entry point. \
     * *Cannot be used with multiple entryPoints or together with `outdir`.*
     * * `buildOptions.absWorkingDir: string`
     * Absolute path to the [esbuild working directory](https://esbuild.github.io/api/#working-directory) and defaults to the [current working directory](https://en.wikipedia.org/wiki/Working_directory). \
     * If paths cannot be found, a good starting point is to look at the concatenation of `absWorkingDir + entryPoint`. It must always be a valid absolute path pointing to the entry point. When needed, the probably easiest way to set absWorkingDir is to use a combination of `resolve` and `__dirname` (see "Library authors" section in the documentation).
     *
     * @see https://esbuild.github.io/api/#build-api
     * @stability stable
     */
    readonly buildOptions?: BuildOptions;
    /**
     * The esbuild Build API implementation to be used.
     *
     * Configure the default `EsbuildProvider` for more options or
     * provide a custom `IBuildProvider` as an escape hatch.
     *
     * @stability stable
     *
     * @default new EsbuildProvider()
     */
    readonly buildProvider?: IBuildProvider;
}
/**
 * Properties for CloudFront Function inline code.
 *
 * @stability stable
 */
export interface CloudFrontFunctionInlineCodeProps extends TransformerProps {
    /**
     * CloudFront Functions JavaScript runtime environment version to build for.
     *
     * @default CloudFrontFunctionRuntime.JS_1_0
     */
    readonly runtime?: CloudFrontFunctionRuntime;
}
/**
 * TypeScript code for CloudFront Functions.
 *
 * @stability stable
 */
export declare class CloudFrontTypeScriptCode {
    /**
     * Create CloudFront Function code from a TypeScript file.
     */
    static fromFile(entryPoint: string, props?: CloudFrontFunctionCodeProps): FunctionCode;
    /**
     * Create CloudFront Function code from inline TypeScript code.
     */
    static fromInline(code: string, props?: CloudFrontFunctionInlineCodeProps): FunctionCode;
}
